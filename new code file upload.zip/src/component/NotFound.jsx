import React from 'react'

const NotFound = () => {
    return (
        <div>
            <h1>Sorry you do not have access for these</h1>
        </div>
    )
}

export default NotFound