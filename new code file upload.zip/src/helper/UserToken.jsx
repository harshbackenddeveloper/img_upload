export const userlocalStorageData = () => {
    const localData = sessionStorage.getItem("token");
    const userRole = sessionStorage.getItem("User_Role");
    const ExpireIn = sessionStorage.getItem("ExpireIn");

    const userToken = JSON.parse(localData);
    const Role_User = JSON.parse(userRole);
    const ExpireInUser = JSON.parse(ExpireIn);

    console.log("flkdklfjdfjdsklfd", ExpireInUser);

    function logMessage() {
        const currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));



        const current_hours = currentTime.getHours();
        const current_minutes = currentTime.getMinutes();

        const future_hour = ExpireInUser.getHours();
        const future_min = ExpireInUser.getMinutes();

        console.log("curent_injjf", current_minutes);
        console.log("future_min", future_min);

        if (current_hours === future_hour && current_minutes >= future_min) {
            console.log("you are logout");
        }
    }

  


    setTimeout(() => {
        setInterval(() => logMessage(), 10000);
    }, 10000);

    const sessionExpire = ExpireInUser;

    return { userToken, Role_User };
};

export const ProperDateFormat = ({ dateString }) => {
    const date = new Date(dateString);
    const day = date.getDate();
    const formattedDay = day < 10 ? `0${day}` : day;
    const month = date.getMonth() + 1;
    const formattedMonth = month < 10 ? `0${month}` : month;
    const year = date.getFullYear();

    return `${formattedDay}/${formattedMonth}/${year}`;
};
